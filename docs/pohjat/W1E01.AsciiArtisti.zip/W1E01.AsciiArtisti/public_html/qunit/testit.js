
/* global QUnit */


QUnit.module("AsciiArtist", {

    before: function (assert) {

        var done = assert.async();
        var that = this;

        $.get("./index.html", function (data) {
            that.pageHtml = data;
            done();
        });
    },

    beforeEach: function () {
        $('#qunit-fixture').append(this.pageHtml);
    }

});


QUnit.test("Otsikko", function (assert) {

    assert.strictEqual($('#qunit-fixture h1').length, 1,
            "yksi h1-tason otsikko");

    assert.ok($('#qunit-fixture h1').text().indexOf("Ascii Artist!") >= 0,
            "otsikkoteksti spesifikaation mukainen");

});


QUnit.test("Kuva", function (assert) {

    assert.strictEqual($('#qunit-fixture pre').length, 1,
            "yksi pre-elementti");

    assert.ok($('#qunit-fixture pre').text().indexOf("   [= =]") > 0,
            "elementissä vaadittua tekstiä (1)");

    assert.ok($('#qunit-fixture pre').text().indexOf("  { ^ } ") > 0,
            "elementissä vaadittua tekstiä (2)");

    assert.ok($('#qunit-fixture pre').text().indexOf(" PRE-ELEMENT!") > 0,
            "elementissä vaadittua tekstiä (3)");

});



