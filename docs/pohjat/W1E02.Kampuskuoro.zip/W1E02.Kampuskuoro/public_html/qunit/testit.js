
/* global QUnit */


QUnit.module("Testaa", {

    before: function (assert) {

        var done = assert.async();
        var that = this;

        $.get("./index.html", function (data) {
            that.pageHtml = data;
            done();
        });
    },

    beforeEach: function () {
        $('#qunit-fixture').append(this.pageHtml);
    }

});


QUnit.test("Sivun pääelementit", function (assert) {

    assert.strictEqual($('#qunit-fixture header').length, 1,
            "yksi header-elementti");

    assert.strictEqual($('#qunit-fixture article').length, 2,
            "kaksi article-elementtiä");

});


QUnit.test("Otsikko", function (assert) {

    assert.strictEqual($('#qunit-fixture header>h1').length, 1,
            "h1 headerissa");

    assert.ok($('#qunit-fixture header>h1').text().indexOf("Kampuskuoro") >= 0,
            "otsikkoteksti ok");

});


QUnit.test("Kuoron kuvaus", function (assert) {

    assert.ok(!!$('#qunit-fixture article:first')
            .text().indexOf("ryhmittymä Kumpulan kampuksen väkeä"),
            "ensimmäinen article-elementti sisältää pyydettyä tekstiä");

    assert.ok(!!$('#qunit-fixture article:first em').length,
            "kuvauksessa korostettua tekstiä (em-elementti)");

});


QUnit.test("Laululista", function (assert) {

    assert.ok($('#qunit-fixture article:last ol').length === 1,
            "jälkimmäisessä article-elementissä numeroitu luettelo (ol)");

    assert.ok($('#qunit-fixture article:last ol>li').length === 3,
            "luettelossa kolme jäsentä");

    assert.ok($('#qunit-fixture article:last ol>li:nth-child(2)')
            .text().indexOf("In questa reggia") >= 0,
            "luettelossa odotettua sisältöä");

});





