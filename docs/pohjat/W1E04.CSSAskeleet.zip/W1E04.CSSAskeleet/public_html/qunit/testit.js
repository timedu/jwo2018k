
//
// päivitetty 180111/TiM
// 

/* global QUnit */


QUnit.module("Testaa", {

    before: function (assert) {

        var done = assert.async();

        $.get("./index.html", function (data) {
            $('#test').empty();
            $('#test').append(data);
            done();
        });
    },

    after: function () {
        $('#test').empty();
    }

});

/*
 * notes
 * 
 * css-tiedostoon viittaava link-elementti on sisällytetty html-tiedostoon, 
 * koska tyylit eivät 'aktivoitune' testauksen näkökulmasta, jos link 
 * css-tiedostoon muodostetaan dynaamisesti:
 *   var $head = $("head");
 *   var $headlinklast = $head.find("link[rel='stylesheet']:last");
 *   var linkElement = "<link rel='stylesheet' href='../style.css' type='text/css'>";
 *   $headlinklast.after(linkElement);
 * 
 * marginaalien testaaminen edellyttää, että testattava sivu on näkyvissä,
 * mistä johtuen tässä käytetään (omaa) #test -elementtiä elementin 
 * #qunit-fixture sijaan
 * 
 */


QUnit.test("Sivun yleisasetukset", function (assert) {

    assert.strictEqual($('body').css('background-color'),
            "rgb(242, 242, 242)", 'taustaväri (vaalean harmaa)');

// -
// 180111/TiM
// 
//    assert.strictEqual($('body').css('font-family'),
//            '"Trebuchet MS",Trebuchet,Arial,sans-serif',
//            'fontti');

    var fontit = $('body').css('font-family').split(',');

    assert.strictEqual(fontit.length, 4, 'sivulle määritelty neljä fonttia');
    assert.strictEqual(fontit[0].trim(), '\"Trebuchet MS\"', 'ensisijainen fontti "Trebuchet MS"');
    assert.strictEqual(fontit[1].trim(), "Trebuchet", 'toisella sijalla "Trebuchet"');
    assert.strictEqual(fontit[2].trim(), "Arial", 'kolmannella sijalla "Arial"');
    assert.strictEqual(fontit[3].trim(), "sans-serif", 'kolmannella sijalla "sans-serif"');
    
// -

});


QUnit.test("Otsikko-osa", function (assert) {

// -
// 180111/TiM
// 
//    assert.strictEqual($('#test header').css('background-color'),
//            "transparent",
//            'header-osan tausta läpinäkyvä (sama kuin sivun taustaväri)');

    var headerBackgroudColor = $('#test header').css('background-color');

    assert.ok(['transparent', 'rgba(0, 0, 0, 0)'].includes(headerBackgroudColor),
            'header-osan tausta läpinäkyvä (sama kuin sivun taustaväri)');

// -

    assert.strictEqual($('#test header h1').css('color'),
            "rgb(10, 10, 10)", 'pääotsikon väri lähes musta');

});


QUnit.test("Artikkelit", function (assert) {

    // Taustaväri

    assert.strictEqual(
            $('#test article').css('background-color'),
            "rgb(255, 255, 255)",
            'artikkelin taustaväri valkoinen');

    // Otsikkotekstin väri

    assert.strictEqual(
            $('#test article h2').css('color'),
            "rgb(252, 179, 21)",
            'artikkelin otsikko kelta-oranssi');

    // Täyte

    assert.ok(
            Number.parseInt($('#test article').css('padding-top')) > 5,
            'sisällön ja raamin välissä tilaa (yläpuoli)');

    assert.ok(
            Number.parseInt($('#test article').css('padding-left')) > 5,
            'sisällön ja raamin välissä tilaa (vasen)');

    assert.ok(
            Number.parseInt($('#test article').css('padding-bottom')) > 5,
            'sisällön ja raamin välissä tilaa (alapuoli)');

    // Raamit

    assert.strictEqual(
            $('#test article:first').css('border-bottom-style'),
            "solid",
            'yhtenäinen raami (1)');

    assert.strictEqual(
            $('#test article:last').css('border-right-style'),
            "solid",
            'yhtenäinen raami (2)');

    assert.strictEqual(
            $('#test article:first').css('border-top-color'),
            "rgb(155, 155, 155)",
            'harmaa raami (1)');

    assert.strictEqual(
            $('#test article:last').css('border-left-color'),
            "rgb(155, 155, 155)",
            'harmaa raami (2)');


    assert.ok(
            Number.parseInt($('#test article:first')
                    .css('border-bottom-width')) > 1,
            'raamin leveys (1)');

    console.log($('#test article:first').css('border-bottom-width'));        
    console.log($('#test article:first').css('border-right-width'));        

    assert.ok(
            Number.parseInt($('#test article:last')
                    .css('border-right-width')) > 1,
            'raamin leveys (2)');

    // Raamin pyöristys

    assert.ok(
            Number.parseInt($('#test article:first')
                    .css('border-bottom-left-radius')) >= 2,
            'raamin pyöristys (1)');

    assert.ok(
            Number.parseInt($('#test article:last')
                    .css('border-top-right-radius')) >= 2,
            'raamin pyöristys (2)');

    // Marginaalit

    assert.ok($('#test h1').offset().left > 5,
            'pääotsikon etäisyys vasemmasta reunasta');

    assert.ok($('#test article:first').offset().left > 5,
            'artikkelin etäisyys vasemmasta reunasta (1)');

    assert.ok($('#test article:last').offset().left > 5,
            'artikkelin etäisyys vasemmasta reunasta (2)');

    var articleFirstBottom =
            $('#test article:first').offset().top +
            $('#test article:first').outerHeight();

    var articleLastTop = $('#test article:last').offset().top;

    assert.ok(articleLastTop - articleFirstBottom > 5,
            'artikkelien välinen etäisyys');

});



