
//
// Nimi:
// OpNro:
//

function sanoKotKot() {

}

function sanoMuuMuu() {

}

function sanoNofNof() {

}
