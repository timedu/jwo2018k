
/* global QUnit, sinon, sanoKotKot, sanoMuuMuu, sanoNofNof, Function */

QUnit.module("Eläintestit", {

    before: function () {
        this.stub = sinon.stub(window, 'alert');
    },
    beforeEach: function (assert) {

        var done = assert.async();

        $.get("./index.html", function (data) {
            $('#qunit-fixture').append(data);
            console.log('before-done');
            done();
        });
    },
    after: function () {
        window.alert.restore();
    }
}, function () {

    QUnit.module("Toiminnot", function () {

        QUnit.test("Sanooko eläin, mitä pitää, kun sen painiketta klikataan?", function (assert) {

            $($('#qunit-fixture input')[0]).click();
            assert.ok(this.stub.calledWith('muu muu'),
                    'lehmä sanoo "muu muu", kun painiketta klikataan');

            $($('#qunit-fixture input')[1]).click();
            assert.ok(this.stub.calledWith('nöf nöf'),
                    'sika sanoo "nöf nöf", kun painiketta klikataan');

            $($('#qunit-fixture input')[2]).click();
            assert.ok(this.stub.calledWith('kot kot'),
                    'kana sanoo "kot kot", kun painiketta klikataan');
        });
    });

    QUnit.module("Funktiot", function () {

        QUnit.test("Löytyvätkö funktiot koodista?", function (assert) {

            assert.ok(typeof sanoMuuMuu !== "undefined" && sanoMuuMuu instanceof Function,
                    'skripti sisältää funktion "sanoMuuMuu"');

            assert.ok(typeof sanoNofNof !== "undefined" && sanoNofNof instanceof Function,
                    'skripti sisältää funktion "sanoNofNof"');

            assert.ok(typeof sanoKotKot !== "undefined" && sanoKotKot instanceof Function,
                    'skripti sisältää funktion "sanoKotKot"');
        });

        QUnit.test("Kutsutaanko funktioita, kun nappeja klikataan?", function (assert) {

            var stubMuu = sinon.stub(window, 'sanoMuuMuu');
            var stubNof = sinon.stub(window, 'sanoNofNof');
            var stubKot = sinon.stub(window, 'sanoKotKot');

            $($('#qunit-fixture input')[0]).click();
            assert.ok(stubMuu.called,
                    'funktiota "sanoMuuMuu" kutsutaan, kun lehmän painiketta klikataan');

            $($('#qunit-fixture input')[1]).click();
            assert.ok(stubNof.called,
                    'funktiota "sanoNofNof" kutsutaan, kun possun painiketta klikataan');

            $($('#qunit-fixture input')[2]).click();
            assert.ok(stubKot.called,
                    'funktiota "sanoKotKot" kutsutaan, kun kanan painiketta klikataan');

            sanoMuuMuu.restore();
            sanoNofNof.restore();
            sanoKotKot.restore();

        }); //QUnit.test
    }); //QUnit.module
}); //QUnit.module


