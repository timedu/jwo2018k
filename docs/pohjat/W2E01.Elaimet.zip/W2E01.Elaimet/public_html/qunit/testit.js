
/* global QUnit, sinon */

QUnit.module("Funktiot", {

    before: function () {
        this.stub = sinon.stub(window, 'alert');
    },

    beforeEach: function (assert) {
        var done = assert.async();
        $.get("./index.html", function (data) {
            $('#qunit-fixture').append(data);
            done();
        });
    },

    after: function () {
        window.alert.restore();
    }
});

QUnit.test("Mitä eläin sanoo?", function (assert) {

    $($('#qunit-fixture input')[0]).click();
    assert.ok(this.stub.calledWith('muu muu'), 'Lehmä sanoo "muu muu".');

    $($('#qunit-fixture input')[1]).click();
    assert.ok(this.stub.calledWith('nöf nöf'), 'Sika sanoo "nöf nöf".');

    $($('#qunit-fixture input')[2]).click();
    assert.ok(this.stub.calledWith('kot kot'), 'Kana sanoo "kot kot".');

});


