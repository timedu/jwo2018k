
//
// Nimi:
// OpNro:
//

/**
 * Lukee sivun input-kentästä sen arvon kokonaislukuna
 * @param {String} tunnus kentän id
 * @returns {Number} kentästä luettu arvo kokonaislukune
 */
function haeNumero(tunnus) {
    return parseInt(document.getElementById(tunnus).value);
}

/**
 * Asettaa tuloksen sivun ao. elementin sisällöksi
 * @param {Number} tulos
 * @returns {undefined}
 */
function asetaTulos(tulos) {
    document.getElementById("tulos").innerHTML = tulos;
}

