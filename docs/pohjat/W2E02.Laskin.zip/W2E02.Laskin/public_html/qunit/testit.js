
/* global QUnit, sinon, haeNumero, asetaTulos */

QUnit.module("Testaa", {

    beforeEach: function (assert) {
        var that = this;
        var done = assert.async();
        $.get("./index.html", function (data) {
            $('#qunit-fixture').append(data);
            that.spy1 = sinon.spy(window, 'haeNumero');
            that.spy2 = sinon.spy(window, 'asetaTulos');
            done();
        });
    },
    afterEach: function () {
        this.spy1.restore();
        this.spy2.restore();
    }
});

QUnit.test("Laskutoimitukset", function (assert) {

    $('#eka').val('6');
    $('#toka').val('2');

    var buttons = $('#qunit-fixture input[type=button]');

    $(buttons[0]).click();
    assert.strictEqual($('#tulos').text(), '8', 'yhteenlasku ok');

    $(buttons[1]).click();
    assert.strictEqual($('#tulos').text(), '4', 'vähennyslasku ok');

    $(buttons[2]).click();
    assert.strictEqual($('#tulos').text(), '12', 'kertolasku ok');

    $(buttons[3]).click();
    assert.strictEqual($('#tulos').text(), '3', 'jakolasku ok');

    assert.strictEqual(this.spy1.callCount, 8, 'haeNumero-funktiota käytetty 8 kertaa');
    assert.strictEqual(this.spy2.callCount, 4, 'asetaTulos-funktiota käytetty 4 kertaa');
});


