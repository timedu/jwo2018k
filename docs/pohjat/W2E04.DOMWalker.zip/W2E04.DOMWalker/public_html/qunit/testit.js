
/* global QUnit */

QUnit.module("Testaa", {});

QUnit.test("div#dom-walker -elementin sisältö", function (assert) {

    var done = assert.async();

    $.get("./index.html", function (data) {

        $('#qunit-fixture').append(data);
        walkDOM();

        assert.equal($('#dom-walker>p').length, 23, 'yhteensä 23 p-elemettiä');

        assert.equal($('#dom-walker>p').filter(function () {
            return $(this).text() === 'HEADER';
        }).length, 1, '1 elementissä on teksi "HEADER"');

        assert.equal($('#dom-walker>p').filter(function () {
            return $(this).text() === 'H1';
        }).length, 1, '1 elementissä on teksi "H1"');

        assert.equal($('#dom-walker>p').filter(function () {
            return $(this).text() === 'NAV';
        }).length, 1, '1 elementissä on teksi "NAV"');

        assert.equal($('#dom-walker>p').filter(function () {
            return $(this).text() === 'UL';
        }).length, 1, '1 elementissä on teksi "UL"');

        assert.equal($('#dom-walker>p').filter(function () {
            return $(this).text() === 'LI';
        }).length, 3, '3 elementissä on teksi "LI"');

        assert.equal($('#dom-walker>p').filter(function () {
            return $(this).text() === 'A';
        }).length, 3, '3 elementissä on teksi "A"');

        assert.equal($('#dom-walker>p').filter(function () {
            return $(this).text() === 'H2';
        }).length, 3, '3 elementissä on teksi "H2"');

        assert.equal($('#dom-walker>p').filter(function () {
            return $(this).text() === 'SECTION';
        }).length, 3, '3 elementissä on teksi "SECTION"');

        assert.equal($('#dom-walker>p').filter(function () {
            return $(this).text() === 'P';
        }).length, 7, '7 elementissä on teksi "P"');

        done();
    });

});

QUnit.test("koodin sisältö", function (assert) {

    var done = assert.async();

    $.get("./js/code.js", function (code) {

        assert.ok(!code.includes('textContent'), 
        'koodi ei viittaa elementin "textContent" -ominaisuuteen');

        assert.ok(!code.includes('innerHTML'), 
        'koodi ei viittaa elementin "innerHTML" -ominaisuuteen');

        done();
    });

});

