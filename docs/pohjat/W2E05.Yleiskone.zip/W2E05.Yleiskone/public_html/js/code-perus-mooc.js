
// kopioi tänne tehtävän 2.3 code.js

