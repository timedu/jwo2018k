
//
// Nimi:
// OpNro:
//

window.addEventListener('load', init);

function init() {

    // Painonappien click-tapahtumien käsittelijöiden määrittely

}


/**
 * Muuntaa Celsius-asteet Fahrenheiteiksi
 * @returns {undefined}
 */

function muunna_celsius_asteiksi() {


}

/**
 * Muuntaa metrit jaloiksi
 * @returns {undefined}
 */

function muunna_fahrenheiteiksi() {


}

/**
 * Muuntaa jalat metreiksi
 * @returns {undefined}
 */

function muunna_metreiksi() {


}


/**
 * Muuntaa metrit jaloiksi
 * @returns {undefined}
 */

function muunna_jaloiksi() {


}

/**
 * Laskee julkaisupisteet
 * @returns {undefined}
 */

function laske_julkaisupisteet() {

}

/**
 * Kasvattaa tykkäämisiä yhdellä
 * @returns {undefined}
 */

function tykkaa() {

}
