
/* global QUnit */

QUnit.module("Testaa", {
    before: function (assert) {
        var that = this;
        var done = assert.async();
        $.get("./index.html", function (data) {
            that.context = '#test-fixture '; // huom. lopussa blankko
            $(that.context).empty();
            $(that.context).append(data);
            init();
            done();
        });
    },
    after: function () {
        $(this.context).empty();
    }
});


QUnit.test("Lämpötilamuunnin", function (assert) {

    $(this.context + '#celsius').val(100);
    $(this.context + '#muunna_fahrenheiteiksi').click();

    assert.equal(Math.round($(this.context + '#fahrenheit').val()), 212,
            'Laskee, että 100 Celsiusta on noin 212 Fahrenheitia');

    $(this.context + '#fahrenheit').val(100);
    $(this.context + '#muunna_celsius_asteiksi').click();

    assert.equal(Math.round($(this.context + '#celsius').val()), 38,
            'Laskee, että 100 Fahrenheitia on noin 38 Celsiusta');
});


QUnit.test("Pituusmuunnin", function (assert) {

    $(this.context + '#jalat').val(100);
    $(this.context + '#muunna_metreiksi').click();

    assert.equal(Math.round($(this.context + '#metrit').val()), 30,
            'Laskee, että 100 jalkaa on noin 30 metriä');

    $(this.context + '#metrit').val(100);
    $(this.context + '#muunna_jaloiksi').click();

    assert.equal(Math.round($(this.context + '#jalat').val()), 328,
            'Laskee, että 100 metriä on noin 328 jalkaa');
});


QUnit.test("Julkaisupistelaskuri", function (assert) {

    $(this.context + '#luokka0').val(2);
    $(this.context + '#luokka1').val(2);
    $(this.context + '#luokka2').val(2);
    $(this.context + '#luokka3').val(2);
    $(this.context + '#laske_julkaisupisteet').click();

    assert.equal(Math.round($(this.context + '#julkaisupisteet').text()), 17,
            'Laskee 17, kun jokaisen luokan julkaisuja on tuotettu 2');

    $(this.context + '#luokka0').val('3 julkaisua');
    $(this.context + '#luokka1').val(2);
    $(this.context + '#luokka2').val(1);
    $(this.context + '#luokka3').val('ei pysty');
    $(this.context + '#laske_julkaisupisteet').click();

    assert.equal(Math.round($(this.context + '#julkaisupisteet').text()), 9,
            'Laskee 9 seuraavilla syötteillä : ' +
            '"Luokka 0: 3 julkaisua, Luokka 1: 2, Luokka 2: 1, Luokka 3: ei pysty"');
});


QUnit.test("Tykkääminen", function (assert) {

    var lkm = parseInt($(this.context + '#tykkaamiset').text());

    $(this.context + '#tykkaa').click();

    assert.equal(parseInt($(this.context + '#tykkaamiset').text()) || 0,
            lkm + 1,
            'Tykkäysnapin klikkaus kasvattaa laskuria yhdellä');
});



