
/* global QUnit, Function */

QUnit.module("Tilaustestit", {

    before: function () {
//        this.stub = sinon.stub(window, 'alert');
    },
    beforeEach: function (assert) {

        var done = assert.async();

        $.get("./index.html", function (data) {
//        $.get("./index-layout-0.html", function (data) {
//        $.get("./index-layout-1.html", function (data) {
//        $.get("./index-layout-2.html", function (data) {
//        $.get("./index-layout-3.html", function (data) {

            $('#qunit-fixture').append(data);

            // head-elementtien poisto
            $('#qunit-fixture>meta').remove();
            $('#qunit-fixture>link').remove();
            $('#qunit-fixture>title').remove();

            //console.log('before-done');
            done();
        });
    },
    after: function () {
//        window.alert.restore();
    }
}, function () {

    QUnit.module("Lähtökohta", function () {

        QUnit.test("Sivun lähtökohtainen rakenne sama kuin tehtäväpohjassa", function (assert) {

            assert.equal($('#qunit-fixture>*').length, 3, 'päätasolla 3 elementtiä');

            assert.equal($('#qunit-fixture>nav:nth-child(1)').length, 1, 'nav');
            assert.equal($('#qunit-fixture>form:nth-child(2)').length, 1, 'form');
            assert.equal($('#qunit-fixture>footer:nth-child(3)').length, 1, 'footer');

            assert.equal($('#qunit-fixture>nav>a').length, 1, 'nav>a');

            assert.equal($('#qunit-fixture>form>div').length, 1, 'form>div');
            assert.equal($('#qunit-fixture>form>*').length, 1, 'form>*');
            assert.equal($('#qunit-fixture>form>div>div').length, 7, 'form>div>div: 7');
            assert.equal($('#qunit-fixture>form>div>*').length, 7, 'form>div>*: 7');

            assert.equal($('#qunit-fixture>form>div>div:nth-child(1)>*').length, 1, 'form>div>div>*: 1');
            assert.equal($('#qunit-fixture>form>div>div:nth-child(2)>*').length, 2, 'form>div>div>*: 2');
            assert.equal($('#qunit-fixture>form>div>div:nth-child(3)>*').length, 2, 'form>div>div>*: 2');
            assert.equal($('#qunit-fixture>form>div>div:nth-child(4)>*').length, 1, 'form>div>div>*: 1');
            assert.equal($('#qunit-fixture>form>div>div:nth-child(5)>*').length, 2, 'form>div>div>*: 2');
            assert.equal($('#qunit-fixture>form>div>div:nth-child(6)>*').length, 1, 'form>div>div>*: 1');
            assert.equal($('#qunit-fixture>form>div>div:nth-child(7)>*').length, 1, 'form>div>div>*: 1');

            assert.equal($('#qunit-fixture>footer>div').length, 1, 'footer>div');
            assert.equal($('#qunit-fixture>footer>div>div').length, 1, 'footer>div>div');
            assert.equal($('#qunit-fixture>footer>div>div>div').length, 1, 'footer>div>div>div');
            assert.equal($('#qunit-fixture>footer>div>div>div>small').length, 1, 'footer>div>div>div>small');

        });

    });

    QUnit.module("Layout", function () {

        QUnit.test("Sisältää odotetut container-, row- ja col-elementit", function (assert) {

            assert.equal($('#qunit-fixture .container').length, 2, 'Sisältää 2 container-elementtiä');

            assert.equal($('#qunit-fixture>form>div.container').length, 1, '- form>div.container');
            assert.equal($('#qunit-fixture>footer>div.container').length, 1, '- footer>div.container');

            assert.equal($('#qunit-fixture .row').length, 8, 'Sisältää 8 row-elementtiä');
            assert.equal($('#qunit-fixture>form>div>div.row').length, 7, '- form>div>div.row: 7');
            assert.equal($('#qunit-fixture>footer>div>div.row').length, 1, '- footer>div>div.row: 1');

            assert.equal($("#qunit-fixture .row>[class|='col']").length, 11, 'Sisältää riveillä 11 "col-*" -elementtiä');

            assert.equal($('#qunit-fixture>form .row:nth-child(2)>.col-sm-2:first-child ').length, 1,
                    '- nimi-kentän otsikko "col-sm-2"-sarakkeessa');

            assert.equal($('#qunit-fixture>form .row:nth-child(3)>.col-sm-2:first-child ').length, 1,
                    '- osoite-kentän otsikko "col-sm-2"-sarakkeessa');

            assert.equal($('#qunit-fixture>form .row:nth-child(5)>.col-sm-2:first-child ').length, 1,
                    '- tuote-nappien otsikko "col-sm-2"-sarakkeessa');

            assert.equal($('#qunit-fixture>form .row:nth-child(4)>.offset-sm-2:first-child ').length, 1,
                    '- opiskelija-laatikon sijaintia siirretty oikealle (offset-sm-2)');

        });
    });

    QUnit.module("Lomake-elementit", function () {

        QUnit.test("Grid sisältää odotetut input- (text, radio, checkbox) ja textarea -elementit", function (assert) {

            assert.equal($('#qunit-fixture input').length, 7, 'Yhteensä 7 input -elementtiä');

            assert.ok($('#qunit-fixture>form>div>div:nth-child(2)>div:nth-child(2) input[type=text]').length,
                    '- Nimi-kenttä (text)');
            assert.ok($('#qunit-fixture>form>div>div:nth-child(3)>div:nth-child(2) input[type=text]').length,
                    '- Osoite-kenttä (text)');

            assert.ok($('#qunit-fixture>form>div>div:nth-child(4) input[type=checkbox]').length,
                    '- Opiskelija-valinta (checkbox)');

            assert.equal($('#qunit-fixture>form>div>div:nth-child(5)>div:nth-child(2) input[type=radio]').length, 3,
                    '- Tuote-valinnat (radio)');
            assert.ok($('#qunit-fixture>form>div>div.row:nth-child(7) input[type=submit]').length,
                    '- Lähetä-painike (submit)');


            assert.equal($('#qunit-fixture textarea').length, 1, 'Yksi textarea-elementti');

            assert.ok($('#qunit-fixture>form>div>div:nth-child(6) textarea').length,
                    '- Erikoistoivomukset-alue (textarea)');

        });
    });



    QUnit.module("Komponentit", function () {

        QUnit.test("Lomake-elementit merkitty Bootstrap-komponenteiksi", function (assert) {

            assert.equal($('#qunit-fixture input[type=text].form-control').length, 2,
                    'Tekstikentillä on "form-control"-luokka ');

            assert.equal($('#qunit-fixture textarea.form-control').length, 1,
                    'Tekstialueella on "form-control"-luokka ');

            assert.equal($('#qunit-fixture input[type=radio].form-check-input, #qunit-fixture input[type=checkbox].form-check-input').length, 4,
                    'Valintanapeilla (radio, checkbox) on "form-check-input"-luokka ');

            assert.equal($('#qunit-fixture input[type=submit].btn.btn-primary').length, 1,
                    'Lähetä-painikkeella on "btn"- ja "btn-primary"-luokat ');


            assert.equal($('#qunit-fixture div[class|=col]>div.form-check>input[type=checkbox]').length, 1,
                    'Opiskelija-valinta kehystetty "form-check"-elementillä (div)');

            assert.equal($('#qunit-fixture div[class|=col]>div.form-check-inline>input[type=radio]').length, 3,
                    'Tuote-valinnat kehystetty "form-check-inline"-elementeillä (div)');


            assert.equal($('#qunit-fixture>nav.navbar.navbar-light.bg-light').length, 1,
                    'Navigointipalkilla (nav) on "navbar"- "navbar-light"- ja "bg-light"-luokat ');

            assert.equal($('#qunit-fixture>nav>a.navbar-brand').length, 1,
                    'Navigointipalkin linkillä (a) on "navbar-brand"-luokka');

        });
    });


    QUnit.module("Loppusilaukset", function () {

        QUnit.test("Pieniä layout-täsmennyksiä", function (assert) {

            assert.equal($('#qunit-fixture div.row.form-group:has(input, textarea)').length, 6,
                    'input- ja textarea-elementtejä sisältävillä "row"-elementeillä on myös "form-control"-luokka');

            assert.ok($('#qunit-fixture footer.border.border-bottom-0').length, 
                    'footer-elementillä on "border" ja "border-bottom-0"-luokat');
        });
                       
    });


}); //QUnit.module


