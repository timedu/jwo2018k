
//
// Käsittelijän määrittely laskentapainikkeiden click-tapahtumille
// 

// ** käytä jQuery:ä 
document.querySelectorAll('#laskin .container-fluid button').forEach(function (button) {
    button.onclick = laske;
});

/**
 * Kaikkiin painonappeihin liitettävä click-tapahtuman käsittelijä, joka 
 * suorittaa laskennan. Funktio saa parametrikseen Event-objektin, jonka 
 * target-ominaisuudessa on tapahtumaan liittyvä elementti; tässä klikattu
 * laskentapainike
 * @param {Event} e
 * @returns {undefined}
 */

function laske(e) {

    //
    // Laskentaan liittyvien painikkeiden otsikkotekstejä
    // vastaavat arvot
    //
    const plus = String.fromCharCode(43);
    const miinus = String.fromCharCode(8722);
    const kerto = String.fromCharCode(215);
    const jako = String.fromCharCode(247);


    // ** käytä jQuery:ä 
    var lasku = e.target.textContent;
    // e : klikkauksen myötä muodostunut objekti
    // e.target : killauksen kohde (painike)
    // e.target.textContent : painikkeen otsikkoteksti ("sisältö")
    // painikkeen sisältönä (textContent) on laskutoimitukseen viittaava
    // merkki, jonka perusteella päätellään, mikä laskutoimitus suoritetaan

    // ** käytä jQuery:ä 
    var luku1 = parseInt(document.getElementById('luku1').value);
    var luku2 = parseInt(document.getElementById('luku2').value);

    var tulos;

    switch (lasku) {
        case plus:
            tulos = luku1 + luku2;
            break;
        case miinus:
            tulos = luku1 - luku2;
            break;
        case kerto:
            tulos = luku1 * luku2;
            break;
        case jako:
            tulos = luku1 / luku2;
            break;
        default:
            console.log('oops!');
    }

    // ** käytä jQuery:ä         
    document.getElementById('tulos').value = `${luku1} ${lasku} ${luku2} = ${tulos}`;
    // edellä sijoituksen oikea puoli vastaa lauseketta: luku1+' '+' '+lasku+' '+luku2+' = '+tulos

}


