
/* global QUnit, sinon */

QUnit.module("Testaa", {
//    beforeEach: function (assert) {
//        var done = assert.async();
//        $.get("./index.html", function (data) {
////        $.get("./index-pohja.html", function (data) {
//            $('#qunit-fixture').append(data);
//            done();
//        });
//    }
    before: function (assert) {
        var done = assert.async();
        $.get("./index.html", function (data) {
//        $.get("./index-pohja.html", function (data) {
            $('#tim-fixture').append(data);
            done();
        });        
    },
    after: function(){
        $('#tim-fixture').empty();
    }    
}, function () {


    QUnit.test("Lähtökohta", function (assert) {

        assert.equal($('#tim-fixture div').length, 13, 'sivulla 13 div-elementtiä');
        assert.equal($('#tim-fixture button').length, 6, 'sivulla 6 button-elementtiä');
        assert.equal($('#tim-fixture input').length, 3, 'sivulla 3 input-elementtiä');
        assert.equal($('#tim-fixture h5').length, 1, 'sivulla 1 h5-elementti');

        assert.equal($('#tim-fixture .container-fluid').length, 1, 'sivulla "container-fluid"');
        assert.equal($('#tim-fixture .container-fluid>.row').length, 2,
                '"container-fluid" sisältää 2 riviä (row)');
        assert.equal($('#tim-fixture .row>.col-sm').length, 4,
                'rivit sisältävät yhteensä 4 saraketta (col-sm)');
    });


    QUnit.test("Laskenta", function (assert) {

        $('#luku1').val('6');
        $('#luku2').val('2');

        var buttons = $('#laskin .container-fluid button');


        $(buttons[0]).click();
        assert.strictEqual($('#tulos').val(), '6 + 2 = 8', 'Yhteenlasku ok');

        $(buttons[1]).click();
        assert.strictEqual($('#tulos').val(), '6 − 2 = 4', 'Vähennyslasku ok');

        $(buttons[2]).click();
        assert.strictEqual($('#tulos').val(), '6 × 2 = 12', 'Kertolasku ok');

        $(buttons[3]).click();
        assert.strictEqual($('#tulos').val(), '6 ÷ 2 = 3', 'Jakolasku ok');

    });

    QUnit.test("Dialogi-ikkunan rakenne", function (assert) {

        assert.ok($('#tim-fixture>#laskin.modal').length,
                'sivulla oikein sijoitettuna "modal"');

        assert.ok($('#tim-fixture>.modal>.modal-dialog').length,
                'sivulla oikein sijoitettuna "modal-dialog"');

        assert.ok($('#tim-fixture>.modal>.modal-dialog>.modal-content').length,
                'sivulla oikein sijoitettuna "modal-content"');

        assert.ok($('#tim-fixture .modal-content>div.modal-header:first-child').length,
                'sivulla oikein sijoitettuna "modal-header"');

        assert.ok($('#tim-fixture .modal-content>.modal-body:last-child').length,
                'sivulla oikein sijoitettuna "modal-body"');

        assert.ok($('#tim-fixture .modal-header>h5.modal-title').length,
                'sivulla oikein sijoitettuna "modal-title"');
    });


    QUnit.test("Dialogi-ikkunan avaaminen ja sulkeminen", function (assert) {

        assert.ok($('#tim-fixture>button[data-toggle="modal"][data-target="#laskin"]').length,
                'Laskin-napilla avaamisen edellyttämät attribuutit (data-toggle, data-target)');

        assert.ok($('#tim-fixture .modal-header button.close').length,
                'Dialogin sulkemisnapilla sitä muoteileva luokka (close)');

        assert.ok($('#tim-fixture .modal-header button[data-dismiss="modal"]').length,
                'Dialogin sulkemisnapilla sulkemisen edellyttämä attribuutti (data-dismiss)');

    });


    QUnit.test("Dialogin sisältämät lomake-elementit", function (assert) {

        assert.equal($('#tim-fixture .container-fluid>.row.form-group').length, 2,
                'Riveille asetettu luokka "form-group"');

        assert.equal($('#tim-fixture input.form-control').length, 3,
                'input-elementteille asetettu luokka "form-control"');

        assert.equal($('#tim-fixture .modal-body button.btn.btn-secondary').length, 4,
                'Laskentapainikkeille asetettu luokat "btn" ja "btn-secondary"');

        assert.equal($('#tim-fixture .modal-body div.btn-group>button').length, 4,
                'Laskentapainikkeet asetetty "btn-group"-elementin (div) sisällöksi');

    });


    QUnit.test("jQuery:n käyttö laskennan yhteydessä", function (assert) {

        $('#luku1').val('6');
        $('#luku2').val('2');
        var buttons = $('#laskin .container-fluid button');

        var b0Events = $._data(buttons[0], "events");
        var b1Events = $._data(buttons[1], "events");
        var b2Events = $._data(buttons[2], "events");
        var b3Events = $._data(buttons[3], "events");

        assert.ok(b0Events && b0Events.click,
                'plus-painikkeen click-käsittelijä määritelty jQuery:llä');
        assert.ok(b1Events && b1Events.click,
                'miinus-painikkeen click-käsittelijä määritelty jQuery:llä');
        assert.ok(b2Events && b2Events.click,
                'kerto-painikkeen click-käsittelijä määritelty jQuery:llä');
        assert.ok(b3Events && b3Events.click,
                'jako-painikkeen click-käsittelijä määritelty jQuery:llä');

        var jQueryProto = Object.getPrototypeOf($(''));
        var textSpy = sinon.spy(jQueryProto, 'text');
        var valSpy = sinon.spy(jQueryProto, 'val');

        $(buttons[0]).click();

        assert.strictEqual(textSpy.callCount, 1, 'text-metodia käytetty kerran');
        assert.strictEqual(valSpy.callCount, 3, 'val-metodia käytetty 3 kertaa');
        assert.ok(valSpy.calledWithExactly('6 + 2 = 8'),
                'val-metodia käytetty tuloksen esittämisessä');

        textSpy.restore();
        valSpy.restore();
    });

});



