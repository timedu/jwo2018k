
/* global QUnit, sinon */

QUnit.module("Testaa", {

    before: function (assert) {
        var done = assert.async();
        $.get("./index.html", function (data) {
//        $.get("./index-pohja.html", function (data) {
            $('#timtest').append(data);
            //console.log('before-done');   
            done();
        });
    },
    after: function(){
        $('#timtest').empty();
        //console.log('after');      
    }
}, function () {

    QUnit.test("Lähtökohta", function (assert) {

        assert.equal($('#timtest nav').length, 1, 'sivulla on 1 nav-elementti');
        assert.equal($('#timtest a').length, 7, 'sivulla on 7 a-elementtiä');
        assert.equal($('#timtest ul').length, 2, 'sivulla on 2 ul-elementtiä');
        assert.equal($('#timtest li').length, 6, 'sivulla on 6 li-elementtiä');
        assert.equal($('#timtest div').length, 11, 'sivulla on 11 div-elementtiä');
        assert.equal($('#timtest h2').length, 4, 'sivulla on 4 h4-elementtiä');
        assert.equal($('#timtest footer').length, 1, 'sivulla on 1 footer-elementti');
        assert.equal($('#timtest small').length, 1, 'sivulla on 1 small-elementti');                
    });
    
    QUnit.test("Yläosan navigointipalkki", function (assert) {

        assert.equal($('#timtest nav ul.navbar-nav').length, 1, 
            'valikolla on luokka "navbar-nav"');
        assert.equal($('#timtest nav li.nav-item').length, 2, 
            'valinnoilla on luokka "nav-item"');
        assert.equal($('#timtest nav li>a.nav-link').length, 2, 
            'valintojen linkeillä on luokka "nav-link"');
        
        assert.equal($('#timtest nav.navbar-dark.bg-dark').length, 1, 
            'navigointipalkilla on luokat "navbar-dark" ja "bg-dark"');
        assert.equal($('#timtest nav.navbar-expand-sm.justify-content-between').length, 1, 
            'navigointipalkilla on luokat "navbar-expand-sm" ja "justify-content-between"');        
    });

    QUnit.test("Välilehtien navigointipalkki", function (assert) {
        
        assert.equal($('#timtest .col-sm>ul.nav.nav-tabs').length, 1, 
            'valikolla on luokat "nav" ja "nav-tabs"');    
            
        assert.equal($('#timtest .col-sm li.nav-item').length, 4, 
            'valinnoilla on luokka "nav-item"');    

        assert.equal($('#timtest .col-sm li>a.nav-link').length, 4, 
            'valintojen linkeillä on luokka "nav-link"');

        assert.equal($('#timtest .col-sm li>a.active').length, 1, 
            'yksi linkeistä on aktiivinen (active)');

        assert.equal($('#timtest .col-sm li>a.active:first-child').length, 1, 
            'aktiivinen on linkeistä ensimäinen');

        assert.equal($('#timtest .col-sm li>a[data-toggle="tab"]').length, 4, 
            'valintojen linkeillä on "data-toggle"-attribuutti');        
    });

    QUnit.test("Välilehdet", function (assert) {
        
        assert.equal($('#timtest .col-sm>div.tab-content').length, 1, 
            'välilehtiryhmällä on luokka "tab-content"');    
        
        assert.equal($('#timtest .col-sm>div>div.tab-pane').length, 4, 
            'välilehdillä on luokka "tab-pane"');    
        
        assert.equal($('#timtest .col-sm>div>div.show.active').length, 1, 
            'ensimmäinen välilehdistä on esillä ja aktiivinen (show, active)');            
    });


    QUnit.test("Alatunniste (footer)", function (assert) {
        
        assert.equal($('#timtest footer.fixed-bottom').length, 1, 
            'alatunniste on sijoitettu selain-ikkunan alareunaan');
        
        assert.equal($('#timtest footer.border.border-bottom-0').length, 1, 
            'alatunnisteen yläpuolinen osa raamista on näkyvissä mutta alapuolinen ei ole');                
    });

});



