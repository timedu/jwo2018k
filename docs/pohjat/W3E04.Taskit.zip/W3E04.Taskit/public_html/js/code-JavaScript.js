
console.log('code-JavaScript');

// 
// Luetteloissa olevien elementtien click-tapahtumien
// käsittelijät: tehtävän siirto listasta toiseen
//

var todoList = document.getElementById('todo-list');
var doneList = document.getElementById('done-list');

todoList.querySelectorAll('.list-group-item').forEach(function (item) {
    item.onclick = moveTask;
});

doneList.querySelectorAll('.list-group-item').forEach(function (item) {
    item.onclick = moveTask;
});

function moveTask(e) {

    var clickedItem = e.target;

    // värin vaihto
    clickedItem.classList.toggle("text-primary");
    clickedItem.classList.toggle("text-danger");

    // elementin siirto
    if (clickedItem.parentElement === todoList) {
        doneList.appendChild(clickedItem);
    } else {
        todoList.appendChild(clickedItem);
    }
}

// 
// Painikkeiden click-tapahtumien käsittelijät
//

var newTask = document.getElementById('new-task');

// uuden tehtävän lisäys
document.getElementById('add-button').onclick = function () {

    let newTaskText = newTask.value.trim();

    if (newTaskText.length) {

        // button-elementin luonti
        let newTaskElement = document.createElement('button');
        
        // elementille teksti, css-luokat ja tapahtumakäsittelijä 
        newTaskElement.textContent = newTaskText;
        newTaskElement.classList.add('list-group-item');
        newTaskElement.classList.add('list-group-item-action');
        newTaskElement.classList.add('text-primary');
        newTaskElement.onclick = moveTask;

        // elementin lisäys todo-luetteloon
        todoList.appendChild(newTaskElement);        
    }
};

// done-listassa olevien tehtävien poisto
document.getElementById('delete-button').onclick = function () {

   doneList.querySelectorAll('.list-group-item').forEach(function(item){
       doneList.removeChild(item);
   });

};


