
console.log('code-JavScript');

const xhr = new XMLHttpRequest();

xhr.onload = function () {

    const tilaus = JSON.parse(xhr.responseText);

    document.querySelector('input[name="nimi"]').value = tilaus.nimi;
    document.querySelector('input[name="osoite"]').value = tilaus.osoite;

    document.querySelector('input[name="opiskelija"]').checked = tilaus.opiskelija;

    document.querySelector('input[name="tuote"][value="vasara"]').checked = (tilaus.tuote ==='vasara');
    document.querySelector('input[name="tuote"][value="saha"]').checked = (tilaus.tuote ==='saha');
    document.querySelector('input[name="tuote"][value="kirves"]').checked = (tilaus.tuote ==='kirves');

    document.querySelector('textarea[name="erikoistoivomukset"]').value = tilaus.erikoistoivomukset;
};

xhr.open('GET', './data/tilaus.json');
xhr.send();
