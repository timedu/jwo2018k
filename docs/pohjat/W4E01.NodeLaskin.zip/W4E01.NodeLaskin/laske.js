
//
// Nimi:
// OppNro:
//

console.log('Hello Node!\n');
