
const { exec } = require('child_process');
const assert = require('assert');

const commandAndOperands = 'node laske 6 2 ';
const expectedResults = {
  '+': 8, '-': 4, 'x': 12, '/': 3,
  'tuntematon': 'oops'
};

Object.keys(expectedResults).forEach(function(operator){

  var messagePrefix = operator + ' :';
  var errorMessage;

  exec(commandAndOperands + operator, (error, stdout) => {

    if(error){
      console.error('error');
      process.exit(1);
    }

    var actualResult = stdout.trim()

    try {
      assert.equal(actualResult, expectedResults[operator]);
    } catch (AssertionError) {
      errorMessage = `not ok\n  actual: ${actualResult}\n  expected: ${expectedResults[operator]}`;
    }
    finally {
      console.log(messagePrefix, errorMessage?errorMessage:'ok');
    }

  }); // exec

}); // forEach
