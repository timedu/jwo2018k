

//
// Nimi:
// OppNro:
//


//
// VERSIO 1
//

// Esimerkkipyyntö:
// http://localhost:3000/?lasku=add&luku1=2&luku2=3

// ...


//
// VERSIO 2
//

// Esimerkkipyyntö:
// http://localhost:3000/add?luku1=2&luku2=3

// ...


//
// VERSIO 3
//

// Esimerkkipyyntö:
// http://localhost:3000/add/2/3

// ...


