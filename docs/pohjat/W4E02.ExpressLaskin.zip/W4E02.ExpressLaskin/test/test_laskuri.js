
// test_laskuri.js

process.env.NODE_ENV = 'test';

const chai = require('chai');
const chaiHttp = require('chai-http');
chai.use(chaiHttp);
const assert = chai.assert;


const host = 'http://localhost:3000';
const operands = {luku1: 6, luku2: 2};
const calcResults = {add: 8, sub: 4, mul: 12, div: 3};


describe('Test Laskuri v.1', function () {

    // Esimerkkipyyntö:
    // http://localhost:3000/?lasku=add&luku1=6&luku2=2

    const path = '/';
    const results = Object.assign({unknown: 'oops'}, calcResults);

    Object.keys(results).forEach(function (lasku) {
        it(`test #${lasku}`, function (done) {
            var params = Object.assign({lasku: lasku}, operands);
            chai.request(host).get(path).query(params).end(function (err, res) {
                if (!err) {
                    assert.equal(res.text, results[lasku]);
                }
                done(err);
            });
        });
    });
}); // Test Laskuri v.1


describe('Test Laskuri v.2', function () {

    // Esimerkkipyyntö:
    // http://localhost:3000/add?luku1=6&luku2=2

    const params = operands;
    const results = Object.assign({unknown: 'hupsista'}, calcResults);

    Object.keys(results).forEach(function (lasku) {
        it(`test #${lasku}`, function (done) {
            var path = `/${lasku}`;
            chai.request(host).get(path).query(params).end(function (err, res) {
                if (!err) {
                    assert.equal(res.text, results[lasku]);
                }
                done(err);
            });
        });
    });
}); // Test Laskuri v.2


describe('Test Laskuri v.3', function () {

    // Esimerkkipyyntö:
    // http://localhost:3000/add/6/2

    const results = calcResults;

    Object.keys(results).forEach(function (lasku) {
        it(`test #${lasku}`, function (done) {
            var path = `/${lasku}/${operands.luku1}/${operands.luku2}`;
            chai.request(host).get(path).end(function (err, res) {
                if (!err) {
                    assert.equal(res.text, results[lasku]);
                }
                done(err);
            });
        });
    });
}); // Test Laskuri v.3
