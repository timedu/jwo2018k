

//
// Nimi:
// OppNro: 
//


// Sovelluskehyksen käyttöönotto
const express = require('express');
const app = express();

// Sivupohjamoottorin käyttöönotto
const hbs = require('express-handlebars');
app.engine('html', hbs());
app.set('view engine', 'html');


app.get('/hello', function (req, res) {
    res.render('hello', {message: "Test page"});
});


app.get('/', function (req, res) {
    
    // res.send('laskin');
    
    const opers = {
        add: String.fromCharCode(43),
        sub: String.fromCharCode(8722),
        mul: String.fromCharCode(215),
        div: String.fromCharCode(247)        
    };
    const operaattoriMerkki = opers[req.query.lasku];
      
    // ...

});


app.get('*', function (req, res) {
    res.status(404).send('hupsista');
});


app.listen(3000, function () {
    console.log('laskuri is listening on localhost:3000');
});


