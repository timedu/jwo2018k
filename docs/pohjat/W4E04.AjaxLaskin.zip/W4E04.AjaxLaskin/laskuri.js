
// Sovelluskehyksen käyttöönotto
const express = require('express');
const app = express();

// Julkinen hakemisto
app.use(express.static('public'));


app.get('/', function (req, res) {
    res.redirect('/laskin.html');
});


//
// Nimi:
// OppNro: 
//


app.get('/api', function (req, res) {

    // ...

});


app.get('*', function (req, res) {
    res.status(404).send('hupsista');
});


app.listen(3000, function () {
    console.log('laskuri is listening on localhost:3000');
});


