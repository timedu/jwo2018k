
//
// Nimi:
// oppNro:
//

$('.btn-group>button').click(function (e) {

    // ...

    const url = `/api?lasku=${lasku}&luku1=${luku1}&luku2=${luku2}`;

    // ...

});
