

//
// Nimi:
// OppNro: 
//


/*
 * ----------------------------------------------------------------
 * Moduulien käyttöönotto ja asetukset
 */

// 
// sovelluskehys 
//

const express = require('express');
const app = express();

//
// sivupohjamoottori
//

const hbs = require('express-handlebars');
app.engine('html', hbs({
    defaultLayout: 'default-layout.html',
    helpers: {
        padZeros: function(value, n){
            return String(value).padStart(n, '0');
        }
    } 
}));
app.set('view engine', 'html');

//
// pyynnön sisällön jäsentäjä
// 

const bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({ extended: true }));


/*
 * ----------------------------------------------------------------
 * "Tietokanta" ja alustusdata
 */

const tilaukset = [];

tilaukset.push({
        nimi: 'Ned Flanders',
        osoite: 'Puuvilla, Pori',
        opiskelija: 'on',
        tuote: 'saha',
        erikoistoivomukset: 'laitteessa tulisi olla polttomoottorimoottori'
});


/*
 * ----------------------------------------------------------------
 * Pyyntöihin vastaaminen
 */


app.get('/', function (req, res) {
    res.redirect('/list');
});

//
// tilauslomake
// 

app.get('/new', function (req, res) {
    
    // (A) ...
    
    res.send('/new');
    
});

//
// tilauksen talletus ja ohjaus talletetun tilauksen esittävälle sivulle
//

app.post('/new', function (req, res) {
    
    // (B) ...
    
    res.redirect('/new');
    
});

//
// yksittäisen tilauksen esittäminen 
//

app.get('/show/:id', function (req, res) {
    
    const id = req.params.id;
    
    res.render('tilaus',{
        id: req.params.id,
        nimi: tilaukset[id].nimi,
        osoite: tilaukset[id].osoite,
        opiskelijaChecked: tilaukset[id].opiskelija?'checked':'',
        vasaraChecked: tilaukset[id].tuote==='vasara'?'checked':'',
        sahaChecked: tilaukset[id].tuote==='saha'?'checked':'',
        kirvesChecked: tilaukset[id].tuote==='kirves'?'checked':'',
        erikoistoivomukset: tilaukset[id].erikoistoivomukset
    });
    
});

//
// tilausluettelo
// 

app.get('/list', function (req, res) {  
    
    // (C) ...
    
    res.send('/list');
});

//
// 404-sivu 
//

app.get('*', function (req, res) {
    res.status(404).send('hupsista');
});

/*
 * ----------------------------------------------------------------
 * Palvelimen käynnistys
 */

app.listen(3000, function () {
    console.log('app is listening on localhost:3000');
});


