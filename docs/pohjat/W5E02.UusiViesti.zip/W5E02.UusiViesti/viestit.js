
//
// Nimi:
// OpNro:
//


const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('./data/viestikanta.db');

const currentDate = require('current-date');
const username = require('username');

/*
* -----------------------------------------------
* suoritettavan operaation päättely
*/

if (process.argv.length === 2) {
  // Usage: node viestit
  doSelect();
} else if (process.argv[2] === '-d') {
  // Usage: node viestit -d 2
  doDelete(parseInt(process.argv[3]));
} else {
  // Usage: node viestit "Hello world!"
  doInsert(purify(process.argv[2]));
}

/*
* -----------------------------------------------
* select
*/

function doSelect() {

  console.log('doSelect');

  // ...

}

/*
* -----------------------------------------------
* insert
*/

function doInsert(sanoma) {

  console.log('doInsert');

  // ...

}

/*
* -----------------------------------------------
* delete
*/

function doDelete(id) {

  console.log('doDelete');

  // ...

}

/*
* -----------------------------------------------
* helpers
*/

function checkError(err) {
  if(err) {
    console.error(err);
    process.exit(1);
  }
}

function purify(text) {
  // puhdistaa tekstin "vihamielisistä" merkeistä
  // ... tbd ...
  return text;
}
