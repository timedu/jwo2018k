<?php

$movie = Array
    (
    'id' => "princessbride",
    'name' => "The Princess Bride",
    'year' => 1987,
    'score' => 95,
    'overview' => Array
        (
        'STARRING' => "Cary Elwes, Robin Wright, Andre the Giant, "
        . "Mandy Patinkin",
        'DIRECTOR' => "Rob Reiner",
        'PRODUCER' => "Arnold Scheinman, Rob Reiner",
        'SCREENWRITER' => "William Goldman",
        'RATING' => "PG",
        'RELEASE DATE' => "September 25, 1987 (USA)",
        'RUNTIME' => "98 min",
        'SYNOPSIS' => "Director Rob Reiner breathes vividly colored cinematic "
        . "life into William Goldman's THE PRINCESS BRIDE, effectively "
        . "evoking the wondrous, wide-eyed spirit of the witty 1973 novel.",
        'RELEASE COMPANY' => "20th Century Fox"
    ),
    'review_count' => 7,
    'reviews' => Array
        (
        Array
            (
            'review' => "One of Reiner's most entertaining films, effective "
            . "as a swashbuckling epic, romantic fable, and satire of "
            . "these genres.",
            'score' => "FRESH",
            'critic' => "Emanuel Levy",
            'publication' => "emanuellevy.com"
        ),
        Array
            (
            'review' => "Based on William Goldman's novel, this is "
            . "a post-modern fairy tale that challenges and affirms the "
            . "conventions of a genre that may not be flexible enough to "
            . "support such horseplay.",
            'score' => "ROTTEN",
            'critic' => "Variety Staff",
            'publication' => "Variety"
        ),
        Array
            (
            'review' => "Rob Reiner's friendly 1987 fairy-tale adventure "
            . "delicately mines the irony inherent in its make-believe "
            . "without ever undermining the effectiveness of the fantasy.",
            'score' => "FRESH",
            'critic' => "Jonathan Rosenbaum",
            'publication' => "Chicago Reader"
        ),
        Array
            (
            'review' => "One of the Top films of the 1980s, if not of all "
            . "time. A treasure of a film that you'll want to watch again "
            . "and again.",
            'score' => "FRESH",
            'critic' => "Clint Morris",
            'publication' => "Moviehole"
        ),
        Array
            (
            'review' => "An effective comedy, an interesting bedtime tale, "
            . "and one of the greatest date rentals of all time.",
            'score' => "FRESH",
            'critic' => "Brad Laidman",
            'publication' => "Film Threat"
        ),
        Array
            (
            'review' => "The lesson it most effectively demonstrates is that "
            . "cinema has the power to turn you into a kid again. As we wish.",
            'score' => "FRESH",
            'critic' => "Phil Villarreal",
            'publication' => "Arizona Daily Star"
        ),
        Array
            (
            'review' => "My name is Marty Stepp.  You killed my father.  "
            . "Prepare to die.",
            'score' => "FRESH",
            'critic' => "Marty Stepp",
            'publication' => "Step by Step Publishing"
        )
    )
);

