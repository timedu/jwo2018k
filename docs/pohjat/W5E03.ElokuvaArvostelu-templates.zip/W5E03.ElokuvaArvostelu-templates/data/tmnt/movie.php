<?php

$movie = [
    'id' => 'tmnt',
    // -
    'name' => 'TMNT',
    'year' => 2007,
    'score' => 33,
    // -
    'overview' => [
        'starring' => 'Patrick Stewart<br/>'
        . 'Mako<br/>'
        . 'Sarah Michelle Gellar<br/>'
        . 'Kevin Smith',
        'director' => 'Kevin Munroe',
        'rating' => 'PG',
        'theatrical_release' => 'Mar 23, 2007',
        'movie_synopsis' => 'After the defeat of their old arch nemesis, '
        . 'The Shredder, the Turtles have grown apart as a family.',
        'mpaa_rating' => 'PG, for animated action violence, some scary '
        . 'cartoon images and mild language',
        'release_company' => 'Warner Bros.',
        'runtime' => '90 mins',
        'genre' => 'Action/Adventure, Comedies, Childrens, Martial Arts, '
        . 'Superheroes, Ninjas, Animated Characters',
        'box_office' => '$54,132,596',
        'links' => '<a href="http://www.ninjaturtles.com">'
        . 'The Official TMNT Site</a>'
    ],
    // -
    'review_count'=> 8,
    'reviews' => [
        [
            'review' => "Ditching the cheeky, self-aware wink that helped to "
            . "excuse the concept's inherent corniness, the movie attempts "
            . "to look polished and 'cool,' but the been-there animation can't "
            . "compete with the then-cutting-edge puppetry of the 1990 "
            . "live-action movie.",
            'score' => 'ROTTEN',
            'critic' => 'Peter Debruge',
            'publication' => 'Variety'
        ],
        [
            'review' => "TMNT is a fun, action-filled adventure that will "
            . "satisfy longtime fans and generate a legion of new ones.",
            'score' => 'FRESH',
            'critic' => 'Todd Gilchrist',
            'publication' => 'IGN Movies'
        ],
        [
            'review' => "It stinks!",
            'score' => 'ROTTEN',
            'critic' => 'Jay Sherman (unemployed)',
            'publication' => ''
        ],
        [
            'review' => "The rubber suits are gone and they've been redone "
            . "with fancy computer technology, but that hasn't stopped "
            . "them from becoming dull.",
            'score' => 'ROTTEN',
            'critic' => 'Joshua Tyler',
            'publication' => 'CinemaBlend.com'
        ],
        [
            'review' => "The turtles themselves may look prettier, but are "
            . "no smarter; torn irreparably from their countercultural "
            . "roots, our superheroes on the half shell have been firmly "
            . "co-opted by the industry their creators once sought to spoof.",
            'score' => 'ROTTEN',
            'critic' => 'Jeannette Catsoulis',
            'publication' => 'New York Times'
        ],
        [
            'review' => "Impersonally animated and arbitrarily plotted, "
            . "the story appears to have been made up as the filmmakers "
            . "went along.",
            'score' => 'ROTTEN',
            'critic' => 'Ed Gonzalez',
            'publication' => 'Slant Magazine'
        ],
        [
            'review' => "The striking use of image and motion allows each "
            . "sequence to leave an impression. It's an accomplished restart "
            . "to this franchise.",
            'score' => 'FRESH',
            'critic' => 'Mark Palermo',
            'publication' => 'Coast (Halifax, Nova Scotia)'
        ],
        [
            'review' => "The script feels like it was computer generated. "
            . "This mechanical presentation lacks the cheesy charm of the "
            . "three live action films.",
            'score' => 'ROTTEN',
            'critic' => 'Steve Rhodes',
            'publication' => 'Internet Reviews'
        ]
    ]
];
