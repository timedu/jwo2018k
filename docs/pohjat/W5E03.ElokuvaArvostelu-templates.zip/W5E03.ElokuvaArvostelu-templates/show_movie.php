<!DOCTYPE html>
<?php include "./data/" . filter_input(INPUT_GET, 'film') . "/movie.php"; ?>
<html>

    <head>        
<?php include './tmpl/page_title.php'; ?>        
        <meta name="description" content="Rancid Tomatoes movie reviews"/>
        <meta name="keywords" content="movie review"/>
        <meta charset="UTF-8"/>
        <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
        <link rel="stylesheet" type="text/css" href="./css/styles.css"/>
    </head>

    <body>

<?php
include './tmpl/page_banner.php';
include './tmpl/page_heading.php';
?>

        <div id="content"> 

        <?php
        include './tmpl/content_banner.php';
        include './tmpl/movie_overview.php';
        include './tmpl/movie_reviews.php';
        include './tmpl/content_footer.php';
        include './tmpl/content_banner.php';
        ?>

        </div>

            <?php include './tmpl/page_banner.php'; ?>

    </body>

</html>
