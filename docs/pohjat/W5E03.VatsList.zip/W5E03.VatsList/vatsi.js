
const striptags = require('striptags');
const sqlite3 = require('sqlite3').verbose();

//
// Nimi:
// OppNro: 
//

// ...

module.exports = function (app) {

    app.get('/', function (req, res) {
        res.redirect('/list');
    });

    app.get('/list', function (req, res) {

        const viestit = [
            {
                id: 20,
                lahettaja: 'lahettaja2',
                sanoma: 'sanoma2',
                aika: '2000-02-02'
            },
            {
                id: 10,
                lahettaja: 'lahettaja1',
                sanoma: 'sanoma1',
                aika: '1000-01-01'
            }
        ];
        const loginUser = 'lahettaja1';
        
        res.render('messages', {
            viestit: viestit,
            loginUser: loginUser
        });
        
        // ...

    });


    app.post('/login', function (req, res) {
        res.cookie('login-user', clean(req.body.username));
        res.redirect('/list');
    });

};



/*
 * helpers
 */

function success(err, res) {
    if (err) {
        res.send(JSON.stringify(err));
    }
    return !err;
}


function clean(text) {
    return striptags(text || '').trim() || 'anynomous';
}

