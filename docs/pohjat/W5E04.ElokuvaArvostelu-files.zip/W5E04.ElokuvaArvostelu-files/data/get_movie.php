<?php

//
// Opnro:
// Nimi:
//


function debug($data) {
    error_log(print_r($data, TRUE));
}


$film = preg_replace("/[^a-zA-Z0-9]/", '', filter_input(INPUT_GET, 'film'));
$reviews = abs(filter_input(INPUT_GET, 'reviews', FILTER_SANITIZE_NUMBER_INT));


define('MOVIE_FILE_PATH', "./data/{$film}/");


if (strlen($film) && file_exists(MOVIE_FILE_PATH)):

    $movie = [];
    $movie['id'] = $film;

    define('INFO_FILE', MOVIE_FILE_PATH . "info.txt");
    define('OVERVIEW_FILE', MOVIE_FILE_PATH . 'overview.txt');
    define('REVIEW_FILE_PATTERN', MOVIE_FILE_PATH . 'review*.txt');

    
    // ...
    
    
else:

    $movie = false;
    
endif;
