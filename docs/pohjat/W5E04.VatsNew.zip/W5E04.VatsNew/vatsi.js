
const currentDate = require('current-date');
const striptags = require('striptags');
const sqlite3 = require('sqlite3').verbose();

//
// Nimi:
// OppNro: 
//

// ...

module.exports = function (app) {

    app.get('/', function (req, res) {
        res.redirect('/list');
    });


    app.get('/list', function (req, res) {

        res.send(req.path);

        // ...

    });


    app.post('/login', function (req, res) {
        res.cookie('login-user', req.body.username.trim());
        res.redirect('/list');
    });


    app.post('/new', function (req, res) {

        // ..

        res.redirect('/list');

    });

};



/*
 * Helpers
 */


function success(err, res) {
    if (err) {
        res.send(JSON.stringify(err));
    }
    return !err;
}

