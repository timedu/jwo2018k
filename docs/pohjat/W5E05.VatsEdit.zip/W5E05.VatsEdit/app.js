
const express = require('express');
const app = express();

const hbs = require('express-handlebars');
app.engine('html', hbs({
    defaultLayout: 'layout',
    extname: '.html',
    helpers: {
        eq: function (val1, val2) {
            return (val1 === val2);
        },
        cond: function (val, tRet, fRet) {
            return val?tRet:fRet;
        }
    }
}));
app.set('view engine', 'html');

const bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({extended: true}));

const cookieParser = require('cookie-parser');
app.use(cookieParser());


require('./vatsi')(app);


app.get('*', function (req, res) {
    res.status(404).send('hupsista');
});

app.listen(3000, function () {
    console.log('app is listening on localhost:3000');
});


