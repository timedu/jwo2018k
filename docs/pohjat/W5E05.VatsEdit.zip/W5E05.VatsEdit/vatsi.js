
const currentDate = require('current-date');
const striptags = require('striptags');
const sqlite3 = require('sqlite3').verbose();

//
// Nimi:
// OpNro: 
//


// ...


module.exports = function (app) {

    app.get('/', function (req, res) {
        res.redirect('/list');
    });

    app.get('/list', function (req, res) {

        res.send(req.path);

        // viestien tulostus tehtävän 5.3 ratkaisusta

    });


    app.post('/login', function (req, res) {
        res.cookie('login-user', req.body.username.trim());
        res.redirect('/list');
    });


    app.post('/new', function (req, res) {

         res.send(req.path);

        // viestin lisäys tehtävän 5.4 ratkaisusta

    });


    app.post('/edit', function (req, res) {
        
         res.send(req.path);

        // ...

    });


    app.post('/remove', function (req, res) {

         res.send(req.path);
        
        // ...

    });
};



/*
 * Helpers
 */


function success(err, res) {
    if (err) {
        res.send(JSON.stringify(err));
    }
    return !err;
}
