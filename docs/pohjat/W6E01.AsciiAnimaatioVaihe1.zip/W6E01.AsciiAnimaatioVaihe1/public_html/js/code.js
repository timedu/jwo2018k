
/* global ANIMATIONS */

(function () { //- moduuli alkaa -//

    //
    // Nimi:
    // Opnro:
    // 

    document.getElementById('start').onclick = function () {

        console.log('animaatio käynnistettiin');
    };


    document.getElementById('stop').onclick = function () {

        console.log('animaatio pysäytettiin');
    };


    document.getElementById('animaatio').onchange = function (e) {

        console.log('animaatioksi valittiin ' + e.target.value);        
    };


    document.getElementById('koko').onchange = function (e) {
        
        console.log('kooksi valittiin ' + e.target.value);        
    };


    document.getElementById('turbo').onclick = nopeus_klikattu;
    document.getElementById('normaali').onclick = nopeus_klikattu;
    document.getElementById('matelu').onclick = nopeus_klikattu;

    function nopeus_klikattu(e) {
        
        console.log('nopeudeksi asetettiin ' + e.target.value + 'ms');                
    }




})(); //- moduuli päättyy -//
