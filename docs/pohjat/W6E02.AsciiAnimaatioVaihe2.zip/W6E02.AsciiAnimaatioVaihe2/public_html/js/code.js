
/* global ANIMATIONS */

(function () {

    //
    // Nimi:
    // Opnro:
    // 



    // kopioi pohjaksi edellisen tehtävän ratkaisu



})();
