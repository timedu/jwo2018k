
//
// Name:
// Student ID: 
//

$(createGame);


//
// Exercise 6.4
//

function createGame() {
    
     console.log('createGame');
     
     // ...

}


//
// Exercise 6.5 (one possible design)
// 


function movePiece(piece) {
    
     console.log('movePiece');

     // ...
     
}


function sufflePieces() {
    
     console.log('sufflePieces');
    
     // ...
     
}


function getCoors(piece) {
    
     console.log('getCoors');
    
    // ...

}


function isMovable(piecePos, emptyPos) {
    
     console.log('isMovable');
   
    // ...

}


function setMovablePieces() {
    
     console.log('setMovablePieces');

    // ...

}

