
const express = require('express');
const app = express();
app.use(express.static('public'));

const hbs = require('express-handlebars');
app.engine('html', hbs({
    defaultLayout: 'layout',
    extname: '.html'
}));
app.set('view engine', 'html');

const bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({extended: true}));
app.use(bodyParser.json());

const cookieParser = require('cookie-parser');
app.use(cookieParser());

const session = require('express-session');
app.use(session({
    secret: 'ssshhhhh',
    resave: false,
    saveUninitialized: true
}));

module.exports = app;

