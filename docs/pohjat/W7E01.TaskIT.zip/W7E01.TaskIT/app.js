

const app = require('./app-config');
require('./taskit');

app.get('*', function (req, res) {
    res.status(404).send('hupsista');
});

app.listen(3000, function () {
    console.log('app is listening on localhost:3000');
});


