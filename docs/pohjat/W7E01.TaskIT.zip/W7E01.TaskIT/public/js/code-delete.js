
console.log('code-delete.js');

$('#delete-button').click(function () {
    deleteTasks();
});


//
// Nimi:
// OpNro: 
//


function deleteTasks() {

    console.log('deleteTasks');

}

