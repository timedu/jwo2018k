
/* global moveTask */

console.log('code-dom.js');

function createTaskElement(taskText, taskID, taskStatus) {
    $('<button/>')
            .addClass('list-group-item')
            .addClass('list-group-item-action')
            .addClass(taskStatus === 'todo' ? 'text-primary' : 'text-danger')
            .data('task-id', taskID)
            .text(taskText)
            .click(moveTask)
            .appendTo(`#${taskStatus}-list`);
}

function moveTaskElement(taskElement, taskStatus) {
    $(taskElement)
            .toggleClass('text-primary')
            .toggleClass('text-danger')
            .appendTo(`#${taskStatus}-list`);
}

function removeDoneElements() {
    $('#done-list *').remove();
}

function removeTaskElements() {
    $('#todo-list *, #done-list * ').remove();
}

