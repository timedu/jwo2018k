
console.log('code-insert.js');


$('#add-button').click(function () {
    var taskText = $('#new-task').val().trim();
    if (taskText.length) {
        insertTask(taskText);
    }
});


//
// Nimi:
// OpNro: 
//


function insertTask(taskText) {
    
    console.log('insertTask');
            
}
