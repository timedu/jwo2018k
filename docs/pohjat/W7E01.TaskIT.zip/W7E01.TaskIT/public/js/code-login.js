
console.log('code-login.js');


$('#login-button').click(function () {
    removeTaskElements();
    $('#login-user').text('');
    login($('#login-input').val().trim());
    $('#login-modal').modal('hide');
});


$('#login-modal').on('show.bs.modal', function () {
    $('#login-input').val($('#login-user').text());
});


function login(loginUser){
    $.ajax({
        method: "POST",
        url: "/api/login",
        data: {"login-user": loginUser}
    }).done(function (response) {
        // console.log(response);
        if (response.err)
            console.error(response.err);
        else {
            $('#login-user').text(loginUser);
            selectTasks();
        }
    });        
}

