
console.log('code-select.js');


//
// Nimi:
// OpNro: 
//


function selectTasks() {

    console.log('selectTasks');

    createTaskElement('Test task', 100, 'todo');

}

