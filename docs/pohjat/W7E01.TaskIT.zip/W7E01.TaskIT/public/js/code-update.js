
console.log('code-update.js');

function moveTask(e) {
    const taskElement = e.target;
    const newTaskStatus =
            $(taskElement).parent().attr('id') === 'todo-list' ? 'done' : 'todo';
    updateTask(taskElement, newTaskStatus);
}


//
// Nimi:
// OpNro: 
//


function updateTask(taskElement, newTaskStatus) {

    console.log('updateTask');
            
}

