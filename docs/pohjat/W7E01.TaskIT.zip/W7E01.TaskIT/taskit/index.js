
console.log('taskit/index.js');

const app = require('../app-config');

const logUserInOrOut = require('./taskit-login');
const listTasks = require('./taskit-select');
const addNewTask = require('./taskit-insert');
const changeTaskStatus = require('./taskit-update');
const removeDoneTasks = require('./taskit-delete');

function checkUserLogin(req, res, next) {
    if (!req.session['login-user']) {
        return res.json({err: 'not logged in'});
    }
    next();
}

function logOutAndRenderUI(req, res) {
    delete req.session['login-user'];
    res.render('taskit');
}

app.get('/', logOutAndRenderUI);
app.post('/api/login', logUserInOrOut);
app.get('/api/taskit', listTasks);

app.use(checkUserLogin);

app.post('/api/taskit', addNewTask);
app.put('/api/taskit/:id', changeTaskStatus);
app.delete('/api/taskit', removeDoneTasks);

