
console.log('taskit-db.js');

const sqlite3 = require('sqlite3').verbose();
const taskitDB = './data/taskit.db';

const createTableTasks = "\
CREATE TABLE IF NOT EXISTS tasks (\
id	INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,\
owner	TEXT NOT NULL,\
task	TEXT NOT NULL,\
status  TEXT NOT NULL DEFAULT 'todo' CHECK (status IN ('todo', 'done'))\
)";

const db = new sqlite3.Database(taskitDB, function (err) {
    if (err) {
        console.error(err);
    } else {
        db.run(createTableTasks, function (err) {
            err && console.error('CREATE TABLE', err);
        });
    }
});

module.exports = db;
