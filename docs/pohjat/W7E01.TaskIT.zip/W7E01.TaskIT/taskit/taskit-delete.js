console.log('taskit-delete.js');

const db = require('./taskit-db');


//
// Nimi:
// OpNro: 
//


const deleteOwnerDoneTasks = "DELETE ...";


function removeDoneTasks(req, res) {

    console.log('addNewTask');

    res.json({
        err: null,
        changes: 3
    });

}

module.exports = removeDoneTasks;

