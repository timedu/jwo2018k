
console.log('taskit-insert.js');

const db = require('./taskit-db');


//
// Nimi:
// OpNro: 
//


const insertTask = "INSERT ...";


function addNewTask(req, res) {
    
    console.log('addNewTask');

    res.json({
        err: null,
        lastID: 95,
        changes: 1
    });

}


module.exports = addNewTask;

