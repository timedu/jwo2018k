console.log('taskit-login.js');

function logUserInOrOut(req, res) {

    //console.log(req.body);
    const newLoginUser = req.body['login-user']?req.body['login-user'].trim():'';
    
    if (newLoginUser.length) {
        req.session['login-user'] = newLoginUser;
    } else {
        delete req.session['login-user'];
    }
    res.json({ok: true});
}

module.exports = logUserInOrOut;