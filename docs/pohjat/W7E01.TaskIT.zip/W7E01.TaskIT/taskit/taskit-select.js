
console.log('taskit-select.js');

const db = require('./taskit-db');


//
// Nimi:
// OpNro: 
//


const selectOwnerTasks = "SELECT ...";


function listOwnerTasks(req, res) {

    console.log('listOwnerTasks');

    res.json({
        err: null,
        rows: [
            {id: 32, owner: 'Ned', task: 'Study', status: 'done'},
            {id: 33, owner: 'Ned', task: 'Examine', status: 'todo'},
            {id: 34, owner: 'Ned', task: 'Research', status: 'todo'}
        ]
    });

}


module.exports = listOwnerTasks;

