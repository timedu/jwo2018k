
console.log('taskit-update.js');

const db = require('./taskit-db');


//
// Nimi:
// OpNro: 
//


const updateTaskStatus = "UPDATE ...";


function changeTaskStatus(req, res) {

    res.json({
        err: null,
        changes: 1
    });

}


module.exports = changeTaskStatus;
